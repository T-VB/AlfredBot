//import built-in Date function through java.util.Date
import java.util.Date;
//create public class AlfredQuotes
public class AlfredQuotes {
    //Create a public String method named "basicGreeting", 
    //does not take in any parameters, Returns a String
    public String basicGreeting() {
        return "Hello, lovely to see you. How are you?";
    }

    public String guestGreeting(String name) {
        return "Hello, " + name;
    }
    //*ninja bonus: add second parameter to guestGreeting
    public String guestGreeting(String name, String dayPeriod) {
        //return "Hello, " + name; *or below with String.format, 
        //and adding a 2nd parameter (String dapPeriod) that is referenced in Test file.
        return String.format("Hello, %s, good %s", name, dayPeriod);
    }
    
    public String dateAnnouncement() {
        Date date = new Date();
        //return "Current date is: " + date; *or below with String.format 
        return String.format("Current date is: %s", date);
    }
    
    public String respondBeforeAlexis(String conversation) {
        //Use if statement if "Alexis" appears in conversation
        if(conversation.indexOf("Alexis") > -1) {
            return "Too slow, what can I do for you?";
        }
        //Use if statement if "Alfred" appears in converstation
        if(conversation.indexOf("Alfred") > -1) {
            return "At your service, Master Wayne";
        }
        //otherwise return
        return "Alrighty then";
    }
    //**Sensei bonus
     
    
	// NINJA BONUS
	// See the specs to overload the guessGreeting method
    // SENSEI BONUS
    // Write your own AlfredQuote method using any of the String methods you have learned!
}

